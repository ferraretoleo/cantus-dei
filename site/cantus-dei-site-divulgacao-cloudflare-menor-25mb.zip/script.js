
const music = document.getElementById('bgMusic');
const musicToggle = document.getElementById('musicToggle');
const musicLabel = musicToggle?.querySelector('.music-label');

let musicPlaying = false;

async function toggleMusic() {
  if (!music) return;

  try {
    if (musicPlaying) {
      music.pause();
      musicPlaying = false;
      musicToggle.setAttribute('aria-pressed', 'false');
      if (musicLabel) musicLabel.textContent = 'Ouvir trilha';
    } else {
      music.volume = 0.45;
      await music.play();
      musicPlaying = true;
      musicToggle.setAttribute('aria-pressed', 'true');
      if (musicLabel) musicLabel.textContent = 'Pausar trilha';
    }
  } catch {
    if (musicLabel) musicLabel.textContent = 'Clique para ouvir';
  }
}

musicToggle?.addEventListener('click', toggleMusic);

const video = document.querySelector('video');

video?.addEventListener('play', () => {
  if (musicPlaying) {
    music.pause();
    musicPlaying = false;
    musicToggle?.setAttribute('aria-pressed', 'false');
    if (musicLabel) musicLabel.textContent = 'Ouvir trilha';
  }
});

const observer = new IntersectionObserver(
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.12 }
);

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

document.getElementById('year').textContent = new Date().getFullYear();

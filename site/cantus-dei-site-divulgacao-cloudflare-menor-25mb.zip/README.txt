CANTUS DEI - SITE DE DIVULGAÇÃO

ARQUIVOS
- index.html
- styles.css
- script.js
- assets/trilha-cantus-dei.m4a
- assets/cantus-dei-demo.mp4

CONTATO CONFIGURADO
E-mail:
leoferrareto2013@gmail.com

WhatsApp:
(43) 98816-2898
Link:
https://wa.me/5543988162898

MÚSICA
A música não inicia automaticamente com som porque navegadores modernos
bloqueiam autoplay com áudio.

No topo existe o botão:
"Ouvir trilha"

Ao clicar, a música começa e fica em loop.

Quando o visitante inicia o vídeo demo, a música de fundo do site é
pausada para não tocar duas trilhas ao mesmo tempo.

CLOUDFLARE PAGES

Opção simples:

1. Extraia o conteúdo deste ZIP.
2. Crie um repositório GitHub para o site.
3. Envie estes arquivos para a raiz do repositório.
4. No Cloudflare:
   Workers & Pages > Create > Pages > Connect to Git
5. Selecione o repositório.
6. Para site estático:
   Build command: deixe vazio
   Build output directory: /
7. Publique.

Também pode usar Wrangler/Workers Static Assets conforme seu fluxo atual.

IMPORTANTE
O vídeo e a música estão dentro da pasta assets.
Não renomeie esses arquivos sem também alterar as referências no index.html.
